from movimiento import movimientos

class Nodo:
    """ Estructura state
    {
        N1: (X,Y),
        N2: (X,Y),
        R1: (X,Y),
        R2: (X,Y),
    }
    """
    def __init__(self, state, profundidad_maxima=10, profundidad_actual=0, padre=None):
        self.state = state  
        self.padre = padre  
        self.hijos = []  
        self.profundidad_maxima = profundidad_maxima
        self.profundidad_actual = profundidad_actual

        # Generar movimientos automáticamente si no se ha alcanzado la profundidad máxima
        if self.profundidad_actual < self.profundidad_maxima:
            self.agregar_movimientos()

    def agregar_hijo(self, hijo):
        # hijo.padre = self  
        hijo.profundidad_actual = self.profundidad_actual + 1
        hijo.profundidad_maxima = self.profundidad_maxima
        self.hijos.append(hijo)

    def agregar_movimientos(self):
        """Agrega los movimientos posibles como hijos del nodo actual."""
        for estado_hijo in movimientos(self.state, self.padre):
            hijo = Nodo(estado_hijo, self.profundidad_maxima, self.profundidad_actual + 1, self)
            self.agregar_hijo(hijo)
            

    def eliminar_hijo(self, hijo):
        if hijo in self.hijos:
            self.hijos.remove(hijo)
            hijo.padre = None  

    def es_raiz(self):
        return self.padre is None

    def es_hoja(self):
        return len(self.hijos) == 0

    def __repr__(self):
        return f"Nodo({self.state})"


def imprimir_arbol(nodo, nivel=0):
    """Imprime la estructura del árbol con indentación."""
    print(" " * (nivel * 4) + f"{nivel}└── {nodo.state}")  # Usa indentación para mostrar la jerarquía
    for hijo in nodo.hijos:
        imprimir_arbol(hijo, nivel + 1)

def imprimir_camino_izquierdo(nodo, nivel=0):
    """Imprime solo el camino izquierdo (primer hijo de cada nodo)."""
    print(" " * (nivel * 4) + f"└── {nodo.state}")
    if nodo.hijos:  # Si tiene hijos, imprime solo el primero (el de la izquierda)
        imprimir_camino_izquierdo(nodo.hijos[0], nivel + 1)


# Ejemplo de uso (ahora se generará el árbol automáticamente hasta la profundidad máxima)
raiz = Nodo({
    "N1": (0,0),
    "N2": (2,0),
    "B1": (0,2),
    "B2": (2,2),
}, profundidad_maxima=30)  # Puedes ajustar la profundidad máxima según necesites

# Imprimir estructura del árbol
imprimir_arbol(raiz)